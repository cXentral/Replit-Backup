import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { db, sql } from "@db/index";

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Initialize database connection check with retries
async function checkDatabaseConnection(retries = 3, delay = 2000) {
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const result = await sql`SELECT NOW()`;
      log(`Database connection successful on attempt ${attempt}`);
      return true;
    } catch (error) {
      const isLastAttempt = attempt === retries;
      log(`Database connection attempt ${attempt}/${retries} failed: ${error}`);

      if (isLastAttempt) {
        if (process.env.NODE_ENV === 'production') {
          throw error;
        }
        log('WARNING: Continuing without database in development mode');
        return false;
      }

      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
  return false;
}

// Request logging middleware
app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  try {
    // Check database connection before starting server
    const dbConnected = await checkDatabaseConnection();
    if (!dbConnected && process.env.NODE_ENV === 'production') {
      throw new Error("Could not connect to database in production");
    }

    const server = registerRoutes(app);

    // Error handling middleware
    app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
      const status = err.status || err.statusCode || 500;
      const message = err.message || "Internal Server Error";

      log(`Error: ${status} - ${message}`);
      res.status(status).json({ message });

      if (status === 500) {
        console.error(err);
      }
    });

    if (app.get("env") === "development") {
      await setupVite(app, server);
    } else {
      serveStatic(app);
    }

    const PORT = process.env.PORT || 5000;
    server.listen(PORT, () => {
      log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    log("Failed to start server: " + error);
    process.exit(1);
  }
})();